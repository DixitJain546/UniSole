package com.example.unisole.interfaces;

import com.example.unisole.models.CartItem;
import com.example.unisole.models.Inventory;
import com.example.unisole.models.InventoryMerchantStore;
import com.example.unisole.models.InventoryPK;
import com.example.unisole.models.Token;


import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface IProductApi {
    @GET("products/categoryproducts/{categoryId}")
    Call<List<Inventory>> getProductByCategoryId(@Path("categoryId") String categoryId);
    @GET("inventory/getproducts/{productId}/{sizeId}/{colorId}/{merchantId}")
    Call<InventoryMerchantStore> getProductByInventoryPK(@Path("productId") String productId, @Path("sizeId") int sizeId, @Path("colorId") int colorId, @Path("merchantId") String merchantId);
    @POST("cart/addtocart/{cartId}")
    Call<CartItem> addToCart(@Path("cartId") String cartId, @Body CartItem cartItem);


}
