package com.example.unisole;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.unisole.adapters.HomeAdapter;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity implements HomeAdapter.CategoryClick {
    private static final String CATEGORY_ID="categoryId";
    private DrawerLayout d1;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    ArrayList<String> list=new ArrayList<>();
    RecyclerView rvCart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        rvCart=findViewById(R.id.recyclerView);
        list.add("Boots");
        list.add("Heels");
        list.add("Shoes");
        list.add("Sneakers");
        list.add("Sandals");
        HomeAdapter homeAdapter=new HomeAdapter(list,HomeActivity.this);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(HomeActivity.this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        rvCart.setLayoutManager(linearLayoutManager);
        rvCart.setAdapter(homeAdapter);
        d1=(DrawerLayout)findViewById(R.id.d1);
        actionBarDrawerToggle= new ActionBarDrawerToggle(this,d1,R.string.Open,R.string.Close);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        d1.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

       final NavigationView navigationView = (NavigationView)findViewById(R.id.nv);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int id = item.getItemId();
                if (id == R.id.home) {
                    Toast.makeText(HomeActivity.this, "My Profile", Toast.LENGTH_SHORT).show();

                } else if (id == R.id.user_profile) {
                    Intent intent=new Intent(HomeActivity.this,UserProfileActivity.class);
                    Toast.makeText(HomeActivity.this, "This is user profile", Toast.LENGTH_SHORT).show();
                    startActivity(intent);


                } else if (id == R.id.Your_order) {
                    Toast.makeText(HomeActivity.this, "your order", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(HomeActivity.this,OrderActivity.class);
                    startActivity(intent);

                } else if (id == R.id.Shopping_cart) {
                    Toast.makeText(HomeActivity.this, "cart", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(HomeActivity.this,CartActivity.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(HomeActivity.this, "My Profile", Toast.LENGTH_SHORT).show();


                }
                return true;


            }


    });


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return actionBarDrawerToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }

    @Override
    public void onClickCategory(String categoryId) {
        Intent intent=new Intent(HomeActivity.this,ProductListActivity.class);
        intent.putExtra(CATEGORY_ID,categoryId);
        startActivity(intent);
    }
}
