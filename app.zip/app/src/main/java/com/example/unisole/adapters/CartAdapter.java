package com.example.unisole.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.unisole.CartActivity;
import com.example.unisole.R;

import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.viewHolder> {
    ArrayList<CartActivity> list = new ArrayList<>();
    Context context;

    public CartAdapter(ArrayList<CartActivity> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_cart_item,parent,false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        CartActivity cartActivity = list.get(position);
        holder.imageView.setImageResource(R.drawable.logo);
      //  holder.textView.setText(cartActivity.getText());

    }

    @Override
    public int getItemCount() {

        return list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        TextView textView1;
        TextView textView2;
      //  TextView textView3;


        public viewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_name_cart);
            textView1=itemView.findViewById(R.id.tv_price_cart);
            textView2=itemView.findViewById(R.id.tv_qty_cart_row);
            imageView=itemView.findViewById(R.id.iv_cart_product);


        }
    }

}
