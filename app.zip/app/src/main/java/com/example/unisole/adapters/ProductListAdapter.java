package com.example.unisole.adapters;

public class ProductListAdapter {
}
