package com.example.unisole;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.unisole.builder.RetrofitBuilder;
import com.example.unisole.interfaces.ILoginApi;
import com.example.unisole.interfaces.IProductApi;
import com.example.unisole.models.Cart;
import com.example.unisole.models.CartItem;
import com.example.unisole.models.Inventory;
import com.example.unisole.models.InventoryMerchantStore;
import com.example.unisole.models.InventoryPK;
import com.example.unisole.models.Product;

import java.io.Serializable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ProductActivity extends AppCompatActivity {
    Retrofit retrofit= RetrofitBuilder.getInstance();
    IProductApi iProductApi=retrofit.create(IProductApi.class);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        TextView product=findViewById(R.id.tv_product_name);
        TextView price=findViewById(R.id.tv_product_price);
        TextView qty=findViewById(R.id.sp_qty);
        TextView productDesc=findViewById(R.id.tv_product_desc);
        TextView size=findViewById(R.id.tv_size_product);
        TextView color=findViewById(R.id.tv_color_product);
        TextView merchant=findViewById(R.id.tv_mechant_product);
        ImageButton addToCart=findViewById(R.id.btn_add_cart);
        ImageButton addedCart=findViewById(R.id.btn_added_to_cart);
        ImageButton buyNow=findViewById(R.id.btn_buy_now);
        String productId=getIntent().getStringExtra("productId");
        int sizeId=getIntent().getIntExtra("sizeId",0);
        int colorId=getIntent().getIntExtra("colorId",0);
        String merchantId=getIntent().getStringExtra("merchantId");
        Call<InventoryMerchantStore> responses=iProductApi.getProductByInventoryPK(productId,sizeId,colorId,merchantId);
        Callback<InventoryMerchantStore> callback=new Callback<InventoryMerchantStore>() {
            @Override
            public void onResponse(Call<InventoryMerchantStore> call, Response<InventoryMerchantStore> response) {
                product.setText(response.body().getInventory().getInventoryPK().getProduct().getProductName());
                price.setText(String.valueOf(response.body().getInventory().getPrice()));
                productDesc.setText(response.body().getInventory().getProductDescription());
                size.setText(String.valueOf(response.body().getInventory().getInventoryPK().getSize().getSizeNumber()));
                color.setText(response.body().getInventory().getInventoryPK().getColor().getColorName());
                merchant.setText(response.body().getMerchantStore().getMerchantStoreName());
                findViewById(R.id.btn_add_cart).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CartItem cartItem=new CartItem();
                        cartItem.setColorId(colorId);
                        cartItem.setProductId(productId);
                        cartItem.setMerchantId(merchantId);
                        cartItem.setQuantity(1);
                        cartItem.setPrice(Integer.parseInt(price.getText().toString()));
                        cartItem.setSizeId(sizeId);
                        if(response.body().getInventory().getQuantity()<=0) {
                            qty.setText("Out Of Stock");
                            addToCart.setVisibility(View.INVISIBLE);
                            buyNow.setVisibility(View.INVISIBLE);
                        }
                        Cart cart=new Cart();
                        cart.setCartId("cart1");
                        Call<CartItem> cartResponses=iProductApi.addToCart("cart1",cartItem);
                        Callback<CartItem> callback1=new Callback<CartItem>() {
                            @Override
                            public void onResponse(Call<CartItem> call, Response<CartItem> response) {
                                Toast.makeText(ProductActivity.this,"Added to cart",Toast.LENGTH_SHORT).show();
                                addToCart.setVisibility(View.INVISIBLE);
                                addedCart.setVisibility(View.VISIBLE);
                            }

                            @Override
                            public void onFailure(Call<CartItem> call, Throwable t) {
                                Toast.makeText(ProductActivity.this,t.getMessage(),Toast.LENGTH_SHORT).show();
                            }
                        };
                        cartResponses.enqueue(callback1);
                    }
                });




            }

            @Override
            public void onFailure(Call<InventoryMerchantStore> call, Throwable t) {
                Toast.makeText(ProductActivity.this,t.getMessage(),Toast.LENGTH_SHORT).show();
            }
        };
        responses.enqueue(callback);
    }
}