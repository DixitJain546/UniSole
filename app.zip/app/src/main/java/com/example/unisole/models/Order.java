package com.example.unisole.models;

import com.google.gson.annotations.SerializedName;

public class Order {

	@SerializedName("orderId")
	private String orderId;

	@SerializedName("userId")
	private String userId;

	public void setOrderId(String orderId){
		this.orderId = orderId;
	}

	public String getOrderId(){
		return orderId;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return userId;
	}

	@Override
 	public String toString(){
		return 
			"Orders{" + 
			"orderId = '" + orderId + '\'' + 
			",userId = '" + userId + '\'' + 
			"}";
		}
}