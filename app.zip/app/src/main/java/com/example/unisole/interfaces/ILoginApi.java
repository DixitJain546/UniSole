package com.example.unisole.interfaces;

import com.example.unisole.models.Token;
import com.example.unisole.models.User;
import com.example.unisole.models.UserLoginDetail;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ILoginApi {
    @POST("user/signup/{roleId}")
    Call<Token> signup(@Body User user, @Path("roleId") int role);
    @POST("user/signin/")
    Call<Token> signin(@Body UserLoginDetail userLogin);

}
